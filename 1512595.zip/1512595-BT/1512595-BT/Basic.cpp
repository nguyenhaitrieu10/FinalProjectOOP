#include "Basic.h"

double Basic::donGiaGoi = 1000;
double Basic::donGiaTruyCap = 200;

Basic::Basic(string _ten, string _CMND, string _diaChi, double _thoiGianGoi, double _luuLuong)
{
	hoTen = _ten;
	CMND = _CMND;
	diaChi = _diaChi;
	thoiGianGoi = _thoiGianGoi;
	luuLuong = _luuLuong;
}

double Basic::tinhCuocDienThoai()
{
	return thoiGianGoi * donGiaGoi;
}

double Basic::tinhTienMang()
{
	return luuLuong * donGiaTruyCap;
}

double Basic::tinhTongTien()
{
	double tienCuoc = tinhCuocDienThoai() + tinhTienMang();
	return tienCuoc * 1.1;
}

Basic * Basic::taoBanSao()
{
	return new Basic(*this);
}

void Basic::nhanThongBao()
{
	cout << "Tong tien cuoc: " << tinhTongTien() << endl;
}

Basic::~Basic()
{
}
