#include "DataFree.h"



DataFree::DataFree(string _ten, string _CMND, string _diaChi, double _cuocThueBao, double _nguongMienPhi, double _thoiGianGoi, double _luuLuong)
	: Basic(_ten, _CMND, _diaChi, _thoiGianGoi, _luuLuong)
{
	cuocThueBao = _cuocThueBao;
	nguongMienPhi = _nguongMienPhi;
}

double DataFree::tinhCuocDienThoai()
{
	return Basic::tinhCuocDienThoai();
}

double DataFree::tinhTienMang()
{
	if (luuLuong <= nguongMienPhi)
		return cuocThueBao;
	else
		return cuocThueBao + (luuLuong - nguongMienPhi)* donGiaTruyCap;
}

double DataFree::tinhTongTien()
{
	return 1.1*(tinhCuocDienThoai() + tinhTienMang());
}

DataFree * DataFree::taoBanSao()
{
	return new DataFree(*this);
}

void DataFree::nhanThongBao()
{
	cout << "Tong tien cuoc: " << tinhTongTien() << endl;
}

DataFree::~DataFree()
{
}
