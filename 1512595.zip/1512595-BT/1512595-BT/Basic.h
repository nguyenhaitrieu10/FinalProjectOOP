#pragma once
#include "IContract.h"
class Basic : public IContract
{
protected:
	string hoTen;
	string CMND;
	string diaChi;
	static double donGiaGoi;
	static double donGiaTruyCap;
	double thoiGianGoi;
	double luuLuong;
public:
	Basic(string _ten, string _CMND, string _diaChi, double _thoiGianGoi = 0, double _luuLuong = 0); 
	virtual double tinhCuocDienThoai();
	virtual double tinhTienMang();
	virtual double tinhTongTien();
	virtual Basic* taoBanSao();
	virtual void nhanThongBao();
	virtual ~Basic();
};


