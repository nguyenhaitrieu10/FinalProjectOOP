#pragma once
#include "DataFix.h"
#include "DataFree.h"
class ListContract
{
private:
	static ListContract* doiTuong;
	vector<IContract*> danhSach;
	ListContract();
public:
	static ListContract* layDanhSach();
	bool themHopDong(IContract* hopDong);
	void thongBaoCuoc();
	virtual ~ListContract();
};

