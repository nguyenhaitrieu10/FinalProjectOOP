#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;
class IContract
{
public:
	virtual double tinhCuocDienThoai() = NULL;
	virtual double tinhTienMang() = NULL;
	virtual double tinhTongTien() = NULL;
	virtual IContract* taoBanSao() = NULL;
	virtual void nhanThongBao() = NULL;
	virtual ~IContract() {};
};

