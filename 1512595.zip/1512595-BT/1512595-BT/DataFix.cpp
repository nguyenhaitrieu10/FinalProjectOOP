#include "DataFix.h"

double DataFix::mucCoDinh = 1000000;

DataFix::DataFix(string _ten, string _CMND, string _diaChi, double _thoiGianGoi, double _luuLuong)
	: Basic(_ten, _CMND, _diaChi, _thoiGianGoi, _luuLuong)
{
}

double DataFix::tinhCuocDienThoai()
{
	return (Basic::tinhCuocDienThoai())*0.9;
}

double DataFix::tinhTienMang()
{
	return mucCoDinh;
}

double DataFix::tinhTongTien()
{
	return 1.1*(tinhCuocDienThoai() + tinhTienMang());
}

DataFix * DataFix::taoBanSao()
{
	return new DataFix(*this);
}

void DataFix::nhanThongBao()
{
	cout << "Tong tien cuoc: " << tinhTongTien() << endl;
}


DataFix::~DataFix()
{
}
