#include "ListContract.h"

int main()
{
	ListContract* danhSach = ListContract::layDanhSach();
	danhSach->themHopDong(new Basic("Teo", "123", "Quan 1", 50, 250));
	danhSach->themHopDong(new DataFree("Ti", "456", "Quan 2", 50000, 200, 50, 250));
	danhSach->themHopDong(new DataFix("Te", "789", "Quan 3", 50, 250));

	danhSach->thongBaoCuoc();

	delete []danhSach;
	return 0;
}