#pragma once
#include "Basic.h"
class DataFree : public Basic
{
private:
	double cuocThueBao;
	double nguongMienPhi;
public:
	DataFree(string _ten, string _CMND, string _diaChi, double _cuocThueBao, double _nguongMienPhi, double _thoiGianGoi = 0, double _luuLuong = 0);
	double tinhCuocDienThoai();
	double tinhTienMang();
	double tinhTongTien();
	DataFree *taoBanSao();
	void nhanThongBao();
	virtual ~DataFree();
};

