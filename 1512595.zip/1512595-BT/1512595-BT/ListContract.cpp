#include "ListContract.h"


ListContract* ListContract::doiTuong = NULL;

ListContract::ListContract()
{
}

ListContract * ListContract::layDanhSach()
{
	if (doiTuong == NULL)
		doiTuong = new ListContract();
	return doiTuong;
}

bool ListContract::themHopDong(IContract* hopDong)
{
	if (hopDong == NULL)
		return false;
	
	danhSach.push_back(hopDong);
	return true;
}

void ListContract::thongBaoCuoc()
{
	for (int i = 0; i < danhSach.size(); i++)
		danhSach[i]->nhanThongBao();
}

ListContract::~ListContract()
{
	for (int i = 0; i < danhSach.size(); i++)
		delete[]danhSach[i];
}
