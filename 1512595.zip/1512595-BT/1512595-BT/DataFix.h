#pragma once
#include "Basic.h"
class DataFix : public Basic
{
private:
	static double mucCoDinh;
public:
	DataFix(string _ten, string _CMND, string _diaChi, double _thoiGianGoi = 0, double _luuLuong = 0);
	double tinhCuocDienThoai();
	double tinhTienMang();
	double tinhTongTien();
	DataFix *taoBanSao();
	void nhanThongBao();
	virtual ~DataFix();
};


